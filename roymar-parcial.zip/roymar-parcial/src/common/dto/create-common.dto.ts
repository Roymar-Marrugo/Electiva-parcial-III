export class CreateCommonDto {}
